package Models;

public enum Priority {
    LOW, MEDIUM, HIGH
}
